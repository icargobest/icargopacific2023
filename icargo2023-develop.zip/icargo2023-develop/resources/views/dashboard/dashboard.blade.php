@include('layouts.app')
@include('partials.navigationCompany')

@include('partials.footer') 