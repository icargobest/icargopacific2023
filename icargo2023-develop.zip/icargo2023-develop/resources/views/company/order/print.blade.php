
@include('partials.header')

<button type="button" class="btn btn-dark btn-sm">
    Print
</button>
