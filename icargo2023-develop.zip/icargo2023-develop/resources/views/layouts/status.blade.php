<!DOCTYPE html>
<link rel="stylesheet" href="{{asset('status/frontend/css/line-awesome.min.css')}}">
<link rel="stylesheet" href="{{asset('status/frontend/css/main.css')}}">


</head>

</html>



